<?php
/**
 * Focus Area Item js template
 */
?>

<div class="jet-search-suggestions__focus-area-item" tabindex="0" aria-label="{{{data.name}}}">
	<div class="jet-search-suggestions__focus-area-item-title">{{{data.name}}}</div>
</div>
